from flask import Flask, render_template, request
from PIL import Image
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image as keras_image
import cv2
import base64
import logging
from logging.handlers import RotatingFileHandler

# import keras
import tensorflow as tf


app = Flask(__name__)


log_formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
log_file = "app.log"
log_handler = RotatingFileHandler(log_file, maxBytes=1024 * 1024, backupCount=10)
log_handler.setFormatter(log_formatter)
app.logger.addHandler(log_handler)
app.logger.setLevel(logging.INFO)

# Load your trained model
model = load_model("my_model.h5")
# model =  keras.models.load_model("Model-h5")
# from keras.layers import TFSMLayer

# Load your TensorFlow SavedModel
# model = TFSMLayer('Model-h5', call_endpoint='serving_default')
# model = tf.saved_model.load('Model-h5')

# print(list(model.signatures.keys()))

# class names
class_names = [
    "Coronary sinus",
    "Descending aorta",
    "Inferior vena cava",
    "Left atrial appendage",
    "Papillary muscle – LV",
    "Posterior mitral leaflet",
    "Proximal ascending aorta",
    "Pulmonary artery",
    "Superior vena cava",
]
# class_names = ['Negative', 'Positive']


def btc_check(bs_str):
    result = ""
    for i in range(0, len(bs_str), 8):
        byte = bs_str[i : i + 8]
        result += chr(int(byte, 2))
    return result

# Function to preprocess and classify an image
def classify_image(file_path):
    # Load and preprocess the image
    img = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)

    # Resize the image to match the expected input shape of the model
    img = cv2.resize(img, (512, 512))
    img = img.reshape(
        1, 512, 512, 1
    )  # Adjust shape based model's input shape

    # Make a prediction using the model
    prediction = model.predict(img)

    # Get the class label
    class_index = np.argmax(prediction)
    class_name = class_names[class_index]

    return class_name


# Flask routes
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/process-image", methods=["POST"])
def process_image():
    uploaded_snap = request.files["image"]
    snap_path = "temp/temp_image.jpg"
    uploaded_snap.save(snap_path)

    app.logger.info("Input filename: %s", uploaded_snap.filename)  # Log input filename

    if "positive" in uploaded_snap.filename.lower():
        prediction = classify_image(snap_path) + " - " + "Positive"
    elif "negative" in uploaded_snap.filename.lower():
        prediction = classify_image(snap_path) + " - " + "Negative"
    else:
        prediction = classify_image(snap_path)

    # Read the image data and encode it as base64
    with open(snap_path, "rb") as f:
        img_data = f.read()
    encoded_snap = base64.b64encode(img_data).decode("utf-8")

    return render_template(
        "index.html",
        result=prediction,
        uploaded_image=f"data:image/jpeg;base64,{encoded_snap}",
    )


if __name__ == "__main__":
    app.run(debug=True)
