from flask import Flask, render_template, request
from PIL import Image
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image as keras_image
import cv2

app = Flask(__name__)

# Load your trained model
model = load_model(r"D:\GUI\my_model.h5")

# Replace this with your actual class names
class_names = ['Coronary sinus', 'Descending aorta', 'Inferior vena cava', 'Left atrial appendage', 'Papillary muscle – LV', 'Posterior mitral leaflet', 'Proximal ascending aorta', 'Pulmonary artery', 'Superior vena cava']

# Function to preprocess and classify an image
def classify_image(file_path):
    # Load and preprocess the image
    img = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)
    # Perform the same preprocessing steps that you used before
    # ...

    # Resize the image to match the expected input shape of the model
    img = cv2.resize(img, (512, 512))
    img = img.reshape(1, 512, 512, 1)  # Adjust the shape based on your model's input shape

    # Make a prediction using the model
    prediction = model.predict(img)

    # Get the class label
    class_index = np.argmax(prediction)
    class_name = class_names[class_index]

    return class_name

# Flask routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process-image', methods=['POST'])
def process_image():
    # Save the uploaded image temporarily
    uploaded_file = request.files['image']
    image_path = 'temp/temp_image.jpg'
    uploaded_file.save(image_path)

    # Classify the image
    result = classify_image(image_path)

    return render_template('index.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)
